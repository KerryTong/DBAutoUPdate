//
//  AppDelegate.m
//  FMDBUpdate
//
//  Created by 仝兴伟 on 2018/12/3.
//  Copyright © 2018年 TW. All rights reserved.
//

/**
 需求:
 1 创建数据库 完成
 2 写入数据
 3 升级数据库 (添加字段/添加表格/升级数据库)
 */



/**
 
 步骤:
 1 必须有一个字段记录当前数据库版本
 2 在每次创建数据库(如果所创建的数据存在，就不会重新创建，这就是为什么必须数据升级)时，我们要判断当前数据库版本号和最新的数据版本号是否一致(不一致就需要升级)
 3 创建数据库
 4 添加数据
 5 版本升级
 
 */


#import "AppDelegate.h"
#import "UserInfoManger.h"
#import "FMDBManger.h"
#import "HandleMessage.h"
@interface AppDelegate ()

@property (weak) IBOutlet NSWindow *window;

@end

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
    // Insert code here to initialize your application
    // 检测数据库是否需要更新
    [[FMDBManger shareManger]checkNeedUpdate];
}

/**
 cloudscreen 创建一个记录版本的表
 cloudscreen 本地创建一个记录工程需要的版本静态变量
 cloudscreen 发布版本号与数据库中版本进行比较，小于当前版本就需要更新
 cloudscreen 更新数据库内容
 cloudscreen 版本号更新需要放在更新数据库内容之后，在没有版本号的数据库版本中，需要去创建版本表
 cloudscreen 数据库自动更新迭代
 */


- (IBAction)createDB:(NSButton *)sender {
  BOOL result =  [[UserInfoManger shareUserInfoManger]prepareData];
  NSLog(@"result == %d", result);
}

// 插入语句
- (IBAction)insertDB:(id)sender {
    UserInfo *user = [[UserInfo alloc]init];
    user.accessToken = @"qwertyuio";
    user.avatarUrl = @"www.baidu.com";
    user.entName = @"百度";
    user.name = @"阿均";
    user.orgName = @"事业部";
    user.phone = @"12345678901";
    user.position = @"打酱油";
    user.email = @"www.aliyun.com";
    user.entId = 123;
    user.userId = 123;
    HandleMessage *me = [[HandleMessage alloc]init];
    NSLog(@"%@", [me propertyValueWithModel:user]);
    
   NSString *sql = [me sqliteStringWithTableName:@"Person" model:user];
    NSLog(@"需要打印 %@", sql);
    
    // 插入语句，model的字段和数据库中的字段必须一致
//    NSString *insertSql = [me insertStringWithTableName:CS_TB_NAME_USERINFO model:user];
//    NSArray *changeArray = [user modleWithModle:user];
//    NSLog(@"插入打印 %@--%@", insertSql,changeArray);
//    [[FMDBManger shareManger]test:insertSql modelArray:changeArray];
    
//    [[UserInfoManger shareUserInfoManger]saveUserInfo:user block:^(BOOL success, NSError *error) {
//        NSLog(@"%d---%@", success,error);
//    }];
    
}

// 查询(根据条件查询/全部)
- (IBAction)executeDB:(id)sender {
    // 根据条件查询
    [[UserInfoManger shareUserInfoManger]queryUserWithUserId:122 block:^(BOOL success, NSError *error) {
        NSLog(@"%d---%@", success,error);
       UserInfo *user =  [UserInfoManger shareUserInfoManger].currentUserInfo;
        NSLog(@"查询===%@", user.name);
    }];
    
    // 查询全部
//    [[UserInfoManger shareUserInfoManger]queryAllUserInfo:^(BOOL success, NSError *error) {
//        NSArray *array = [UserInfoManger shareUserInfoManger].allUsers;
//        for (UserInfo *info in array) {
//            NSLog(@"%@", info.name);
//        }
//    }];
    
}

- (IBAction)addTitle:(id)sender {
}

- (IBAction)addTable:(id)sender {
}

// 删除
- (IBAction)delete:(id)sender {
//    UserInfo *user = [[UserInfo alloc]init];
//    user.userId = 142;
//    [[UserInfoManger shareUserInfoManger]deleteUserInfo:user block:^(BOOL success, NSError *error) {
//        NSLog(@"%hhd---%@", success,error);
//    }];
    
    [[UserInfoManger shareUserInfoManger]deleteUserInfoWithUserId:12 block:^(BOOL success, NSError *error) {
        NSLog(@"%hhd---%@", success,error);
    }];
    
//    [[UserInfoManger shareUserInfoManger]deleteAllUserInfo:^(BOOL success, NSError *error) {
//        NSLog(@"%hhd---%@", success,error);
//    }];
}






















@end
