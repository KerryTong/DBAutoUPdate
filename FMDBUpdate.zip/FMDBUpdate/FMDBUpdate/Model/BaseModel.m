//
//  BaseModel.m
//  FMDBUpdate
//
//  Created by 仝兴伟 on 2018/12/3.
//  Copyright © 2018年 TW. All rights reserved.
//

#import "BaseModel.h"

@implementation BaseModel
- (instancetype)initWithDict: (NSDictionary *) dict {
    self = [super init];
    if (self) {
        [self setValuesForKeysWithDictionary: dict];
    }
    return self;
}

+ (instancetype)statusWithDic: (NSDictionary *) dict { return [[self alloc] initWithDict: dict]; }

- (NSDictionary *)dictionary { return nil; }

- (void)setValue:(id)value forUndefinedKey:(NSString *)key {}

- (id)copyWithZone:(NSZone *)zone {
    BaseModel * model = [[[self class] allocWithZone: zone] init];
    return model;
}
@end
