//
//  UserInfo.m
//  FMDBUpdate
//
//  Created by 仝兴伟 on 2018/12/3.
//  Copyright © 2018年 TW. All rights reserved.
//

#import "UserInfo.h"

@implementation UserInfo

- (NSArray *)modleWithModle:(UserInfo *)model {
     NSMutableArray *mutArray = [NSMutableArray array];
    [mutArray addObject:model.accessToken];
    [mutArray addObject:model.avatarUrl];
    [mutArray addObject:model.entName];
    [mutArray addObject:model.name];
    [mutArray addObject:model.orgName];
    [mutArray addObject:model.phone];
    [mutArray addObject:model.position];
    [mutArray addObject:model.email];
//    [mutArray addObject:[NSNumber numberWithInt:model.entId]];
//    [mutArray addObject:[NSNumber numberWithInt:model.userId]];
    return mutArray;
}
@end
