//
//  UserInfo.h
//  FMDBUpdate
//
//  Created by 仝兴伟 on 2018/12/3.
//  Copyright © 2018年 TW. All rights reserved.
//

#import "BaseModel.h"

@interface UserInfo : BaseModel
@property (nonatomic, strong) NSString *accessToken;

@property (nonatomic, strong) NSString *avatarUrl;

@property (nonatomic, strong) NSString *entName;

@property (nonatomic, strong) NSString *name;

@property (nonatomic, strong) NSString *orgName;

@property (nonatomic, strong) NSString *phone;

@property (nonatomic, strong) NSString *position;

@property (nonatomic, strong) NSString *email;

@property (nonatomic, assign) int entId;

@property (nonatomic, assign) int userId;

/**
 数据源拼接匹配数组
 
 @param model 数据源
 @return 数据源拼接匹配数组
 */
- (NSArray *)modleWithModle:(UserInfo *)model;
@end
