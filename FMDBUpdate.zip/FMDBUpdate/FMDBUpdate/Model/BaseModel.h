//
//  BaseModel.h
//  FMDBUpdate
//
//  Created by 仝兴伟 on 2018/12/3.
//  Copyright © 2018年 TW. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BaseModel : NSObject<NSCopying>

- (instancetype)initWithDict: (NSDictionary *) dict;

+ (instancetype)statusWithDic: (NSDictionary *) dict;

- (NSDictionary *)dictionary;

@end
