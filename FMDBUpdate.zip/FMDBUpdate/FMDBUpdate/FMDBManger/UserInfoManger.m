//
//  UserInfoManger.m
//  FMDBUpdate
//
//  Created by 仝兴伟 on 2018/12/3.
//  Copyright © 2018年 TW. All rights reserved.
//

#import "UserInfoManger.h"
#import "FMDBManger.h"

#define TB_USERINFO_KEY_USERID       @"user_id"
#define TB_USERINFO_KEY_NAME         @"name"
#define TB_USERINFO_KEY_EMAIL        @"email"
#define TB_USERINFO_KEY_ENTID        @"ent_id"
#define TB_USERINFO_KEY_ENTNAME      @"ent_name"
#define TB_USERINFO_KEY_ORGNAME      @"org_name"
#define TB_USERINFO_KEY_PHONE        @"phone"
#define TB_USERINFO_KEY_AVATARURL    @"avatar_url"
#define TB_USERINFO_KEY_POSITION     @"position"
#define TB_USERINFO_KEY_ACCESSTOKEN  @"access_token"

@interface UserInfoManger ()

@property (nonatomic, strong) dispatch_queue_t asyncTaskQueue;

@end



@implementation UserInfoManger

+ (instancetype) shareUserInfoManger {
    static UserInfoManger *intance;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        intance = [[self alloc]init];
        intance.asyncTaskQueue = dispatch_queue_create("com.cloudscreen.server.cloudbox.db.async", DISPATCH_QUEUE_CONCURRENT);
    });
    return intance;
}


- (BOOL)prepareData {
    __block BOOL result = NO;
    [[FMDBManger shareManger]checkTableExist:CS_TB_NAME_USERINFO block:^(BOOL success, NSError *error) {
        result = success;
        if (!success) {
            // 创建表
            NSString * createSql = [NSString stringWithFormat: @"CREATE TABLE IF NOT EXISTS '%@' ('%@' INTEGER PRIMARY KEY, '%@' TEXT, '%@' TEXT, '%@' INTEGER, '%@' TEXT, '%@' TEXT, '%@' TEXT, '%@' TEXT, '%@' TEXT, '%@' TEXT)", CS_TB_NAME_USERINFO, TB_USERINFO_KEY_USERID, TB_USERINFO_KEY_NAME, TB_USERINFO_KEY_EMAIL, TB_USERINFO_KEY_ENTID, TB_USERINFO_KEY_ENTNAME, TB_USERINFO_KEY_ORGNAME, TB_USERINFO_KEY_PHONE, TB_USERINFO_KEY_AVATARURL, TB_USERINFO_KEY_POSITION, TB_USERINFO_KEY_ACCESSTOKEN];
            
            [[FMDBManger shareManger]executeSQL:createSql block:^(BOOL success, NSError *error) {
                if (success) {
                    result = success;
                }
            }];
        } 
    }];
    return result;
}


- (void)saveUserInfo:(UserInfo *)userInfo block:(DBCompleteBlock)block {
    if (!userInfo) {
        NSError * error = [NSError errorWithDomain: @"user info empty error" code: 1 userInfo: nil];
        block(NO, error);
        return;
    }
    
    self.currentUserInfo = userInfo;
    dispatch_async(self.asyncTaskQueue, ^{
        // 检测表是否存在
        [self prepareData];
        NSString * insertSql = [NSString stringWithFormat: @"INSERT OR REPLACE INTO %@ ('%@', '%@', '%@', '%@', '%@', '%@', '%@', '%@', '%@', '%@') VALUES('%d', '%@', '%@', %d,'%@', '%@', '%@', '%@', '%@', '%@')",
                               CS_TB_NAME_USERINFO,
                               TB_USERINFO_KEY_USERID,
                               TB_USERINFO_KEY_NAME,
                               TB_USERINFO_KEY_EMAIL,
                               TB_USERINFO_KEY_ENTID,
                               TB_USERINFO_KEY_ENTNAME,
                               TB_USERINFO_KEY_ORGNAME,
                               TB_USERINFO_KEY_PHONE,
                               TB_USERINFO_KEY_AVATARURL,
                               TB_USERINFO_KEY_POSITION,
                               TB_USERINFO_KEY_ACCESSTOKEN,
                               userInfo.userId,
                               userInfo.name ? userInfo.name.sqlString : @"",
                               userInfo.email,
                               userInfo.entId,
                               userInfo.entName ? userInfo.entName.sqlString : @"",
                               userInfo.orgName ? userInfo.orgName.sqlString : @"",
                               userInfo.phone ? userInfo.phone : @"",
                               userInfo.avatarUrl ? userInfo.avatarUrl : @"",
                               userInfo.position ? userInfo.position : @"",
                               userInfo.accessToken];
        
        [[FMDBManger shareManger]executeSQL:insertSql block:block];
    });
}


- (void)queryUserWithUserId:(int)userId block:(DBCompleteBlock)block {
    if (!userId) {
        NSError * error = [NSError errorWithDomain: @"userId is empty" code: 1 userInfo: nil];
        block(NO, error);
        return;
    }
    
    dispatch_async(self.asyncTaskQueue, ^{
        NSString * querySql = [NSString stringWithFormat: @"SELECT * FROM %@ WHERE %@=%d",CS_TB_NAME_USERINFO, TB_USERINFO_KEY_USERID, userId];
        __block int result = -1;
        [[FMDBManger shareManger]executeQuerySQL:querySql block:^(BOOL success, NSError *error, FMResultSet *rs) {
            if (success) {
                NSMutableArray *arrM = [[NSMutableArray alloc]init];
                if (rs != nil) { // 这个地方是有问题的
                    while (rs.next) {
                        NSMutableDictionary *dictM = [[NSMutableDictionary alloc]init];
                        // [rs columnNameToIndexMap] 返回一个带索引的字典 key-value形式的 "user_id" = 0;
                        // [rs columnCount] 返回一个列的数量
                        // cloumnNameForIndex 这个方法可以根据索引查找每个列下的列名，在这进行了一个遍历是比较安全的，防止字段重复
                        for (int i = 0; i < [[[rs columnNameToIndexMap]allKeys]count]; i++) {
                           dictM[[rs columnNameForIndex: i]] = [rs objectForColumnIndex: i]; // 这是查询出列名以及列名对应的值通过字典赋值
                        }
                        [arrM addObject:dictM];
                        result = 1;
                    }
                    [rs close];
                     self.currentUserInfo = [[UserInfo alloc] initWithDict: arrM.firstObject];
                }
            }
        }];
        if (!result) {
            NSError * error = [NSError errorWithDomain: @"load user info error" code: 1 userInfo: nil];
            block(result, error);
        } else {
            block(result, nil);
        }
    });
}


- (void)queryAllUserInfo:(DBCompleteBlock)block {
    dispatch_async(self.asyncTaskQueue, ^{
        // 检测表是否创建成功
        [self prepareData];
        
        NSString * querySql = [NSString stringWithFormat: @"SELECT * FROM %@", CS_TB_NAME_USERINFO];
        
        __block int result = -1;
        [[FMDBManger shareManger]executeQuerySQL:querySql block:^(BOOL success, NSError *error, FMResultSet *rs) {
            result = success;
            @autoreleasepool {
                if (success) {
                    NSMutableArray *arrM = [[NSMutableArray alloc]init];
                    if (rs != nil) {
                        while (rs.next) {
                            NSMutableDictionary* dictM = [[NSMutableDictionary alloc] init];
                            
                            for (int i = 0; i < [[[rs columnNameToIndexMap] allKeys] count]; i++) {
                                dictM[[rs columnNameForIndex: i]] = [rs objectForColumnIndex: i];
                            }
                            UserInfo * userInfo = [[UserInfo alloc] initWithDict: dictM];
                            [arrM addObject: userInfo];
                        }
                        [rs close];
                        if (self.allUsers) {
                            self.allUsers = nil;
                        }
                        self.allUsers = [arrM copy];
                        [arrM removeAllObjects];
                        arrM = nil;
                    }
                }
            }
        }];
        
        if (!result) {
            NSError * error = [NSError errorWithDomain: @"load all user info error" code: 1 userInfo: nil];
            block(result, error);
        } else {
            block(result, nil);
        }
    });
}


- (void)deleteUserInfo:(UserInfo *)userInfo block:(DBCompleteBlock)block {
    if (!userInfo) {
        NSError * error = [NSError errorWithDomain: @"user info empty error" code: 1 userInfo: nil];
        block(NO, error);
        return;
    }
    [self deleteUserInfoWithUserId:userInfo.userId block:block];
}

- (void)deleteUserInfoWithUserId:(int) userId block:(DBCompleteBlock)block {
    if (!userId) {
        NSError * error = [NSError errorWithDomain: @"user info empty error" code: 1 userInfo: nil];
        block(NO, error);
        return;
    }
    
    dispatch_async(self.asyncTaskQueue, ^{
        NSString * deleteSql = [NSString stringWithFormat: @"DELETE FROM %@ WHERE %@=%d", CS_TB_NAME_USERINFO, TB_USERINFO_KEY_USERID, userId];
        [[FMDBManger shareManger]executeSQL:deleteSql block:block];
    });
}


- (void)deleteAllUserInfo: (DBCompleteBlock) block {
    dispatch_async(self.asyncTaskQueue, ^{
        NSString * deleteSql = [NSString stringWithFormat: @"DELETE  FROM %@", CS_TB_NAME_USERINFO];
        [[FMDBManger shareManger] executeSQL: deleteSql block: block];
    });
}


- (void)updateUserInfo:(UserInfo*)userInfo block:(DBCompleteBlock)block {
    if (!userInfo) {
        NSError * error = [NSError errorWithDomain: @"user info empty error" code: 1 userInfo: nil];
        block(NO, error);
        return;
    }
    
    dispatch_async(self.asyncTaskQueue, ^{
        
    });
}




@end
