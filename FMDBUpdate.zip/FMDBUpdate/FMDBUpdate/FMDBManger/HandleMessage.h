//
//  HandleMessage.h
//  FMDBUpdate
//
//  Created by 仝兴伟 on 2018/12/5.
//  Copyright © 2018年 TW. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HandleMessage : NSObject


/**
 获取 model 中的所有属性数组

 @param model model对象
 @return 返回属性数组
 */
- (NSArray *)ivarsArrayWithModel:(NSObject *)model;


/**
 数据库表的创建语句

 @param tableName 表的名字
 @param model model对象
 @return 创建数据库表语句
 */
- (NSString *)sqliteStringWithTableName:(NSString *)tableName model:(NSObject *)model;


/**
 获取属性的类型，并且转化为c的类型，并进行拼接

 @param attribleArray 属性的数组
 @param model model对象
 @return 返回c的字符数组
 */
- (NSArray *)attribleArray:(NSArray *)attribleArray model:(NSObject *)model;


/**
 插入数据库语句

 @param tableName 表名
 @param model model 对象
 @return 插入数据库语句的string
 */
-  (NSString *)insertStringWithTableName:(NSString *)tableName model:(NSObject *)model;


/**
 更新数据库的语句
 
 @param tableName 表名字
 @param model modle对象
 @return 插入数据库语句的string
 */
- (NSString *)updateStringWithTableName:(NSString *)tableName  model:(NSObject *)model updateKey:(NSString *)updateKey;

/**
 获得modle的所有属性
 
 @param obj 对象
 @return 属性数组对应的值
 */
- (NSArray *)propertyValueWithModel:(id)obj;


@end
