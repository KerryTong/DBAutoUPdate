//
//  FMDBManger.h
//  FMDBUpdate
//
//  Created by 仝兴伟 on 2018/12/3.
//  Copyright © 2018年 TW. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FMDB.h"

typedef void (^DBCompleteBlock)(BOOL success, NSError * error);

typedef void (^DBInsertCompleteBlock)(BOOL success, NSError * error, int64_t rowId);

typedef void (^DBQueryCompleteBlock)(BOOL success, NSError * error, FMResultSet * rs);


@interface FMDBManger : NSObject

@property (nonatomic, strong) FMDatabaseQueue * dbQueue;

@property (nonatomic, assign) BOOL inTransaction;


+ (instancetype)shareManger;


/**
 检查表是否存在
 @param tableName sql执行语句
 */
- (void)checkTableExist: (NSString *) tableName block: (DBCompleteBlock) block;

/**
 单条查询语句
 @param sql sql执行语句
 */
- (void)executeQuerySQL: (NSString *) sql block: (DBQueryCompleteBlock) block;

/**
 单条插入语句，返回最后一条rowid
 @param sql sql执行语句
 */
- (void)executeInsertSQL: (NSString *) sql block: (DBInsertCompleteBlock) block;

/**
 单条插入语句，不返回rowid
 @param sql sql执行语句
 */
- (void)executeSQL: (NSString *) sql block: (DBCompleteBlock) block;

/**
 插入多条数据
 @param sqlList 数组sql执行语句
 */
- (void)executeSQLList: (NSArray *) sqlList block: (DBCompleteBlock) block;

// 使用自己封装的事物，插入多条数据
/**
 使用自己封装的事物，插入多条数据
 @param sqlList 数组sql执行语句
 */
- (void)executeTransactionSQLList: (NSArray *)sqlList withBlock: (DBCompleteBlock) block;


/**
 检测数据库是否需要更新
 */
- (void)checkNeedUpdate;

/**
 准备数据
 */
- (void) prepareTable;

- (void)test:(NSString *)sql modelArray:(NSArray *)array;


@end

@interface NSString (SQL)
- (NSString *)sqlString;
@end
