//
//  FMDBManger.m
//  FMDBUpdate
//
//  Created by 仝兴伟 on 2018/12/3.
//  Copyright © 2018年 TW. All rights reserved.

// 创建数据库(判断是数据库是否存在，如果存在不创建不存在创建)
// 创建表
// 大量写入数据
// 表格添加字段
// 数据库添加表格
// https://www.cnblogs.com/PeterWolf/p/6211905.html
// https://www.cnblogs.com/PeterWolf/p/7272545.html
#import "FMDBManger.h"
// 查询版本返回值
typedef void (^DBQueryVersionBlock)(BOOL success, NSError * error, int dbVersion);
#define CSIPCKeyDBInfoType           @"type"
#define CSIPCKeyDBInfoValue          @"value"
#define TB_DB_INFO_KEY_VERSION       @"version"

NSString *const MyDBNameFolder = @"myDB"; // 文件夹
NSString *const MyDBName = @"student.db"; // 数据库名称

static NSString * dbPath() {
    NSFileManager *fileManger = [NSFileManager defaultManager];
    static NSString *dbpath;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        if (!dbpath) {
            NSString *dbpaths = [NSSearchPathForDirectoriesInDomains(NSDesktopDirectory, NSUserDomainMask, YES)objectAtIndex:0];
            dbpath = [dbpaths stringByAppendingPathComponent:MyDBNameFolder];
        }
        NSError *error = nil;
        if (![fileManger createDirectoryAtPath:dbpath withIntermediateDirectories:YES attributes:nil error:&error]) {
            dbpath = nil;
        }
        
    });
    return dbpath;
}


@implementation FMDBManger

+ (instancetype)shareManger {
    static FMDBManger *instance;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[self alloc]init];
    });
    return instance;
}

- (instancetype)init {
    if ([super init]) {
        // 数据库路径
       NSString *path = [dbPath() stringByAppendingPathComponent:MyDBName];
        NSFileManager *fileManger = [NSFileManager defaultManager];
        if (![fileManger fileExistsAtPath:path]) {
            [fileManger createFileAtPath:path contents: nil attributes: nil];
        }
        // 创建数据库
        self.dbQueue  = [FMDatabaseQueue databaseQueueWithPath:path];
    }
    return self;
}

// 检查表是否存在
- (void)checkTableExist: (NSString *) tableName block: (DBCompleteBlock) block {
    __block BOOL result;
    [self executeDB:^(FMDatabase * _Nonnull db) {
        result = [db tableExists:tableName];
    }];
    block(result,nil);
}

// 单条查询
- (void)executeQuerySQL: (NSString *) sql block: (DBQueryCompleteBlock) block {
    [self executeDB:^(FMDatabase * _Nonnull db) {
        FMResultSet *rs = [db executeQuery:sql];
        if (rs == nil) {
            NSError *error = [NSError errorWithDomain:@"execute query error" code:1 userInfo:nil];
            block(NO,error,nil);
        } else {
            block(YES,nil,rs);
        }
    }];
}

// 单条插入语句，返回最后一条rowid
- (void)executeInsertSQL: (NSString *) sql block: (DBInsertCompleteBlock) block {
    __block BOOL result;
    __block int64_t rowId;
    [self executeDB:^(FMDatabase * _Nonnull db) {
        result = [db executeUpdate:sql];
        rowId = db.lastInsertRowId;
    }];
    
    if (result) {
        block(result,nil,rowId);
    } else {
        NSString * domain = [NSString stringWithFormat: @"execute sql %@ error!!!", sql];
        NSError * error = [NSError errorWithDomain: domain code: 1 userInfo: nil];
        block(result, error, 0);
    }
}


// 单条插入语句，不返回rowid
- (void)executeSQL: (NSString *) sql block: (DBCompleteBlock) block {
    __block BOOL result;
    [self executeDB:^(FMDatabase * _Nonnull db) {
        result  = [db executeUpdate:sql];
    }];
    
    if (result) {
        block(result,nil);
    } else {
        NSString * domain = [NSString stringWithFormat: @"execute sql %@ error!!!", sql];
        NSError * error = [NSError errorWithDomain: domain code: 1 userInfo: nil];
        block(result, error);
    }
}

// 插入多条数据 手动把操作添加到事物中，并且手动提交
- (void)executeSQLList: (NSArray *) sqlList block: (DBCompleteBlock) block {
    __block BOOL result;
    [self executeDB:^(FMDatabase * _Nonnull db) {
        // 操作放入事物中(加入事物操作)
        [db beginTransaction];
        for (NSString *sql in sqlList) {
            result = [db executeUpdate:sql];
        }
        // 提交事物
        [db commit];
    }];
    if (result) {
        block(result, nil);
    } else {
        NSError * error = [NSError errorWithDomain: @"execute sql error!!!" code: 1 userInfo: nil];
        block(result, error);
    }
}


// 使用自己封装的事物，插入多条数据
- (void)executeTransactionSQLList: (NSArray *)sqlList withBlock: (DBCompleteBlock) block {
    @autoreleasepool {
        __block NSInteger num = 0;
        [self inTransaction:^BOOL{
            for (NSString *sql in sqlList) {
                [self executeSQL:sql block:^(BOOL success, NSError *error) {
                    if (success) {
                        num++;
                    }
                }];
            }
            return YES;
        }];
        if (num == sqlList.count) {
            block(YES,nil);
        } else {
            NSError * error = [NSError errorWithDomain: @"execute sql error!!!" code: 1 userInfo: nil];
            block(NO, error);
        }
    }
}


/**
 检测数据库更新
 */
-(void)checkNeedUpdate {
    // 查询数据库信息表是否存在
    [self checkTableExist:CS_TB_NAME_DB_INFO block:^(BOOL success, NSError *error) {
        if (success) {
            // 存在数据库信息表
            NSLog(@"存在数据库信息表");


        } else {
            // 不存在数据库信息表，则去建
            NSLog(@"不存在数据库信息表");
            NSString * createSql = [NSString stringWithFormat: @"CREATE TABLE IF NOT EXISTS '%@' ('%@' TEXT ,'%@' TEXT,CONSTRAINT PKEY PRIMARY KEY('%@'))", CS_TB_NAME_DB_INFO, CSIPCKeyDBInfoType,CSIPCKeyDBInfoValue,CSIPCKeyDBInfoType];
            [self executeSQL:createSql block:^(BOOL success, NSError *error) {
                if (!success) {
                    NSLog(@"创建数据库信息表失败");
                }else {
                    NSLog(@"创建数据库信息表成功");

                }
            }];
        }
    }];
}



// 手动更新

// 自动更新


- (void) prepareTable {
   
}

// 获取当前数据库版本
- (void)getDBVersion:(DBQueryVersionBlock)block {
    __block int dbVersion = -1;
    __block BOOL result;
    NSString * querySql = [NSString stringWithFormat: @"SELECT * FROM %@ WHERE %@ = '%@'",                                   CS_TB_NAME_DB_INFO,CSIPCKeyDBInfoType,TB_DB_INFO_KEY_VERSION];
    [self executeDB:^(FMDatabase * _Nonnull db) {
        FMResultSet *rs = [db executeQuery:querySql];
        if (rs !=nil) {
            if (rs.next) {
                result = YES;
                dbVersion = [[rs objectForColumn:CSIPCKeyDBInfoValue]intValue];
            }
            [rs close];
        }
    }];
    block(result,nil,dbVersion);
}

// 插入
- (void)insertCurrentDBVersion {
    NSString * insertVersionSql = [NSString stringWithFormat:@"INSERT OR REPLACE INTO %@ ('%@','%@') VALUES('%@',%d)",CS_TB_NAME_DB_INFO,CSIPCKeyDBInfoType,CSIPCKeyDBInfoValue,TB_DB_INFO_KEY_VERSION,CS_DB_VERSION];
    [self executeInsertSQL:insertVersionSql block:^(BOOL success, NSError *error, int64_t rowId) {
        if (!success) {
            NSLog(@"插入失败");
        }
    }];
    
}

- (void)test:(NSString *)sql modelArray:(NSArray *)array {
    [self executeDB:^(FMDatabase * _Nonnull db) {
        BOOL result = [db executeUpdate:sql withArgumentsInArray:array];
        if (result) {
            NSLog(@"插入数据成功");
        } else {
            NSLog(@"插入数据失败");
        }
    }];
}

/**
 事物操作
 */
- (void)inTransaction: (BOOL (^_Nonnull)(void))block {
    NSAssert(block, @"block is null!");
    [self executeDB:^(FMDatabase * _Nonnull db) {
        self->_inTransaction = db.isInTransaction;
        if (!self->_inTransaction) {
            self->_inTransaction = [db beginTransaction];
        }
        BOOL isCommit = NO;
        isCommit = block();
        if (self->_inTransaction) {
            if (isCommit) {
                [db commit];
            } else {
                [db rollback];
            }
            self->_inTransaction = NO;
        }
    }];
}

/**
 为了对象层的事物操作而封装的函数.
 */
-(void)executeDB: (void (^_Nonnull)(FMDatabase *_Nonnull db)) block {
    NSAssert(block, @"block is nill!");
    //    if (_db) {//为了事务操作防止死锁而设置.
    //        block(_db);
    //        return;
    //    }
    [self.dbQueue inDatabase:^(FMDatabase *db) {
        //        __strong typeof(weakSelf) strongSelf = weakSelf;
        //        strongSelf.db = db;
        block(db);
        //        strongSelf.db = nil;
    }];
}

@end

@implementation NSString (SQL)

- (NSString *)sqlString  {
    NSString *sqlText;
    if (self.length>0) {
        sqlText = [self stringByReplacingOccurrencesOfString:@"'" withString:@"''"];
        sqlText = [sqlText stringByReplacingOccurrencesOfString:@"%" withString:@"/%%"];
    }
    return sqlText;
}

@end
