//
//  UserInfoManger.h
//  FMDBUpdate
//
//  Created by 仝兴伟 on 2018/12/3.
//  Copyright © 2018年 TW. All rights reserved.
// 增 删 改 查

#import <Foundation/Foundation.h>
#import "UserInfo.h"
#import "FMDB.h"
typedef void (^DBCompleteBlock)(BOOL success, NSError * error);

typedef void (^DBInsertCompleteBlock)(BOOL success, NSError * error, int64_t rowId);

typedef void (^DBQueryCompleteBlock)(BOOL success, NSError * error, FMResultSet * rs);

@interface UserInfoManger : NSObject

@property (nonatomic, strong)UserInfo *currentUserInfo;

@property (nonatomic, strong) NSArray *allUsers;

+ (instancetype) shareUserInfoManger;


/**
 检测表是否存在,不存在就去建
 */
- (BOOL)prepareData;


/**
 添加用户信息
 @param userInfo 用户信息
 */
- (void)saveUserInfo:(UserInfo *)userInfo block:(DBCompleteBlock)block;


/**
 根据某个字段进行查询
 @param userId 要查询的字段
 */
- (void)queryUserWithUserId:(int )userId block:(DBCompleteBlock)block;


/**
 查询全部
 */
- (void)queryAllUserInfo:(DBCompleteBlock)block;


/**
 根据模型删除
 */
- (void)deleteUserInfo:(UserInfo *)userInfo block:(DBCompleteBlock)block;


/**
 根据模型的userID删除
 */
- (void)deleteUserInfoWithUserId:(int) userId block:(DBCompleteBlock)block;


/**
 删除所有的用户信息
 */
- (void)deleteAllUserInfo: (DBCompleteBlock) block;


/**
 修改某字段
 */
- (void)updateUserInfo:(UserInfo*)userInfo block:(DBCompleteBlock)block;

// 数据库升级


@end
