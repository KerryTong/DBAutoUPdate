//
//  BaseEnum.h
//  FMDBUpdate
//
//  Created by 仝兴伟 on 2018/12/5.
//  Copyright © 2018年 TW. All rights reserved.
//

//数据库表字段类型
typedef NS_ENUM(NSUInteger, DBTableColumnType) {
    DBTableColumnTypeText = 0,
    DBTableColumnTypeInteger,
    DBTableColumnTypeInt,
    DBTableColumnTypeFloat,
    DBTableColumnTypeDouble
};

#ifndef BaseEnum_h
#define BaseEnum_h


#endif /* BaseEnum_h */
